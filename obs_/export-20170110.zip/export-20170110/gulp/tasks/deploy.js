'use strict';

var gulp = require('gulp');

gulp.task('deploy', function() {

  // Any deployment logic should go here

});